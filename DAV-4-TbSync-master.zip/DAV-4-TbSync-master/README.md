# DAV-4-TbSync
This provider add-on adds CalDAV & CardDAV synchronization capabilities to [TbSync](https://github.com/jobisoft/TbSync/).

More information can be found in the [wiki](https://github.com/jobisoft/DAV-4-TbSync/wiki/About:-Provider-for-CalDAV-&-CardDAV) of this repository

## Icon sources and attributions

#### CC-BY 3.0
* [ics16.png] by [FatCow Web Hosting](https://www.iconfinder.com/icons/35803/)
* [icloud16.png] by [Five Icons](https://www.iconfinder.com/icons/252111/apple_icon)
* [yahoo16.png] by [Five Icons](https://www.iconfinder.com/icons/252070/yahoo_icon)
* [gmx16.png] by [CloudSponge](https://www.iconfinder.com/icons/1175604/address_book_contact_contacts_email_gmx_square_icon)
