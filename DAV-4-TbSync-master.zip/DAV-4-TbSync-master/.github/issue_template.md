## Your environment

TbSync version:
DAV-4-TbSync version:
Thunderbird version:

[ ] Yes, I have installed the latest available (beta) version from 
 - https://github.com/jobisoft/TbSync/releases 
 - https://github.com/jobisoft/DAV-4-TbSync/releases 
and my issue is not yet fixed, I can still reproduce it.


## Expected behavior
...

## Actual behavior
...

## Steps to reproduce
...

To help resolving your issue, enable debug logging (TbSync Account Manager -> Help) and send me the debug.log via e-mail (use the title of your issue as subject of the email).
